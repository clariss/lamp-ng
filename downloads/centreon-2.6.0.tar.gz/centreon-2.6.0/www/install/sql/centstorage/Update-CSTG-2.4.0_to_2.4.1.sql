
create index host_name on `hosts` (`name`);
create index service_description on `services` (`description`);
