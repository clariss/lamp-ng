

DROP TABLE `log_archive_file_name`;