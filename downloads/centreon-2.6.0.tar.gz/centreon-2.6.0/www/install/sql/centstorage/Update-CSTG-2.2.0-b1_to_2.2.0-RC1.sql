ALTER TABLE `index_data` CHANGE `host_name` `host_name` varchar(255) DEFAULT NULL;
ALTER TABLE `index_data` CHANGE `service_description` `service_description` varchar(255) DEFAULT NULL;
