ALTER TABLE `centreon_acl` DROP `id`;
