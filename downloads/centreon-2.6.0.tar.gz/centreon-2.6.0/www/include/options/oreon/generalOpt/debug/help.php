<?php
$help = array();

/**
 * Debug
 */

$help['tip_logs_directory'] = dgettext('help', 'Directory of log files.');
$help['tip_authentication_debug'] = dgettext('help', 'Enables authentication debug.');
$help['tip_nagios_import_debug'] = dgettext('help', 'Enables Monitoring Engine import debug.');
$help['tip_rrdtool_debug'] = dgettext('help', 'Enables RRDTool debug.');
$help['tip_ldap_user_import_debug'] = dgettext('help', 'Enables LDAP user import debug.');
$help['tip_sql_debug'] = dgettext('help', 'Enables SQL debug.');
$help['tip_centcore_debug'] = dgettext('help', 'Enables Centcore debug.');
$help['tip_centstorage_debug'] = dgettext('help', 'Enables Centstorage debug.');
$help['tip_centreontrapd_debug'] = dgettext('help', 'Enables Centreontrapd debug.');
