<?php
$help = array();

/**
 * snmpd
 */

$help['tip_global_community'] = dgettext('help', 'SNMP global community.');
$help['tip_version'] = dgettext('help', 'SNMP version.');

/**
 * snmptrapd
 */

$help['tip_directory_of_traps_configuration_files'] = dgettext('help', 'Directory of trap configuration files.');
$help['tip_snmpttconvertmib_directory+binary'] = dgettext('help', 'snmpttconvertmib binary with complete path.');
$help['tip_snmptt_log_file'] = dgettext('help', 'SNMPTT log file.');
$help['tip_perl_library_directory'] = dgettext('help', 'Perl library directory.');
$help['tip_init_script_snmptt'] = dgettext('help', 'SNMPTT init script. This options is used only if snmptt is used in daemon mode.');